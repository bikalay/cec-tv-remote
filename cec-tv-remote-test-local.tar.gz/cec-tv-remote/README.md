# CEC TV Remote

Control a Raspberry Pi over HDMI-CEC and expose the TV remote as a mouse/keyboard bridge on Linux.

## Install

1. Download the generated `cec-tv-remote-<version>.tar.gz` archive.
2. Extract it on the target machine.
3. Run:

```bash
sudo ./install.sh
```

Useful options:

- `--user <name>`: install for a specific Linux user
- `--no-tray`: skip desktop autostart for `cec_tray.py`
- `--skip-deps`: skip `apt-get` package installation
- `--install-dir <path>`: override the default `/opt/cec-tv-remote`

## Release Archive

GitHub Actions builds a release archive from tags matching `v*` and also supports manual runs through `workflow_dispatch`.
